#' Analysis of MicroCal ITC data
#' 
#' nwc.itc provides a framework for the analysis of ITC data starting from the thermogram (time vs. power)
#' 
#' @import magrittr ggplot2 stringr plyr baseline gaussquad
#' @docType package
#' @name nwc.itc
NULL

#' PFOMT ITC data
#'
#' This data is ITC data, where the binding of a small molecule towards the methyl transferase PFOMT was measured
#'
#' @docType data
#' @keywords datasets
#' @name pfomt
#' @format An object of class \code{itc} with three measurements
NULL

#' Read ITC data from time vs power
#' 
#' Read Raw ITC data from \code{*.itc} files created by MicroCal ITC software.
#' 
#' @param file The filename to load.
#' @param comment.chars an \link{regexp} defining which characters are treated as comment characters during the parsing of the file
#' @param sep the separator for the data; typically a ','
#' @return A list object of type \code{itc} containing the elements
#'  \item{X}{A numeric vector of the time data}
#'  \item{data}{The measurement data (cp, temperatures and something ???) included in the \code{*.itc} file.}
#'  \item{tmp}{A list containing all the data that was preceded by \code{comment.chars}}
#'  @author Benjamin Weigel (bweigel@@ipb-halle.de)
#' @export
readITC <- function(file = NULL, comment.chars = "[#$?%]", sep=","){
  
  if(is.null(file)) file <- file.choose()
  if(!file.exists(file)) stop("File does not exist. Aborting")
  data <- readLines(file)
  
  CMNT <- data %>% str_detect(pattern = comment.chars)  
  comments <- data[CMNT] 
  
  injections.at <- data[!CMNT] %>% grep(pattern = "[@]", x = ., perl = T) %>% 
    `-`(1) %>% 
    data[!CMNT][.] %>%
    str_extract(., pattern = "[0-9]+[.]+[0-9]*") %>% 
    as.numeric
  
  a <- data[!CMNT] %>% grep(pattern = "[@]", x = ., perl = T)
  data <- data[!CMNT][-a] %>%
    str_trim() %>%
    str_split(pattern= sep) %>% 
    unlist %>% as.numeric %>%
    matrix(data = ., nrow = length(data[!CMNT][-a]), byrow = T) %>%
    as.data.frame
  
  if(ncol(data) == 3) colnames(data) <- c("time", "cp", "temp")
  if(ncol(data) == 7) colnames(data)[c(1,2,5)] <- c("time", "cp", "temp")
  
  X <- data$time
  data <- list(X = X, data = data, tmp = comments)
  class(data) <- "itc"
  
  param <- .paramsITC(data)
  data <- append(data, param)
  data$tmp <- NULL
  data$inj.program$injections.at <- injections.at
  
  class(data) <- "itc"
  
  plot(data)
  return(data)
}

#' Convert Comments to Experimental Data
#' 
#' Read Raw ITC data from \code{*.itc} files created by MicroCal ITC software.
#' 
#' @param object raw \code{itc} object
#' @param vars a character vector of \link{regexp}s defining which characters are treated as Injection 
#' @param sep the separator for the data; typically a ','
#' @return A list object of type \code{itc} containing the elements
#'  \item{measurement_parameters}{A structured list of experimental data, that was parsed from the \code{itc} raw object}
#'  \item{X}{A numeric vector of the time data}
#'  \item{data}{The measurement data (cp, temperatures and something ???) included in the \code{*.itc} file.}
#'  @author Benjamin Weigel (bweigel@@ipb-halle.de)
#' @export
.paramsITC <- function(object = NULL, vars = c("[$]", "[#]", "[%]"), IN = "[@]", sep=","){
  
  if(!class(object) == "itc") stop("Please supply an object of type 'itc'.")
  DAT <- object$tmp
  
  tmp <-list()
  
  for(expr in vars){
    tmp <- DAT %>% 
      str_detect(string = ., pattern = expr) %>% 
      DAT[.] %>%
      str_replace_all(string = ., pattern = expr, replacement = "") %>%
      str_trim() %>% list() %>%
      append(tmp, values = ., after = length(tmp))
  }
  
  # find injection parameters
  NOM <- lapply(tmp,FUN = function(x){str_detect(string = x, pattern = "^(ITC)$")}) %>%
    lapply(., sum) %>% unlist %>% as.logical
  names(tmp)[NOM] <- "inj.program"
  
  # Instrument Parameters
  NOM <- lapply(tmp,FUN = function(x){str_detect(string = x, pattern = "^[(VP)(ITC)](.)*(Ver){1}(.)*$")}) %>%
    lapply(., sum) %>% unlist %>% as.logical
  names(tmp)[NOM] <- "system.coefficients"
  
  # Concentrations
  NOM <- lapply(tmp,FUN = function(x){!str_detect(string = x, pattern = "^[0-9]+[.]*[0-9]*$")}) %>%
    lapply(., sum) %>% unlist %>% as.logical
  names(tmp)[!NOM] <- "concentrations"
  
  # Injection Parameters
  XP <- tmp$inj.program %>% 
    str_detect(pattern = "[[:digit:]]+[.]?[[:digit:]]+[ ,]+") 
  program <- tmp$inj.program[XP] %>%
    str_split(pattern = sep) %>%
    unlist %>% as.numeric %>%
    matrix(data = ., ncol = 4, byrow = T) %>%
    as.data.frame  
  inj.program <- tmp$inj.program[!XP] 
  names(program) <- c("volume", "duration", "spacing", "filter")
  # program %<>% mutate(cumulative.time = cumsum(spacing) - (as.numeric(tmp$inj.program[5]))
  
  tmp$inj.program <- list(program = program,
                          no.of.inj = as.numeric(tmp$inj.program[2]),
                          cell.temp.set = as.numeric(tmp$inj.program[4]),
                          initial.delay = as.numeric(tmp$inj.program[5]),
                          stirring.speed = as.numeric(tmp$inj.program[6]),
                          reference.power = as.numeric(tmp$inj.program[7]),
                          filter.period = as.numeric(tmp$inj.program[8]),
                          equilibration.options = tmp$inj.program[10] %>% str_split(pattern = "[,]") %>% unlist %>% toupper %>% as.logical)
  
  # Concentrations
  tmp$concentrations <- list(syringe = as.numeric(tmp$concentrations[2]), 
                             cell = as.numeric(tmp$concentrations[3]),
                             cell.volume = as.numeric(tmp$concentrations[4]),
                             cell.temp.set = as.numeric(tmp$concentrations[5]),
                             DP.Mid.Gn.FB = as.numeric(tmp$concentrations[6]),
                             as.numeric(tmp$concentrations[7]))
  
  if(grepl(x=tmp$system.coefficients[1], pattern = "^(ITC)")){
    tmp$system.coefficients <- list(system = tmp$system.coefficients[1],
                                    cell.volume = as.numeric(tmp$system.coefficients[2]),
                                    tmp$system.coefficients[3],
                                    jacket.t.read = tmp$system.coefficients[4] %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    shield.t.read = tmp$system.coefficients[5] %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    deltaT.read = as.numeric(tmp$system.coefficients[6]),
                                    Cal.Htr = tmp$system.coefficients[7]  %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    min.max.safetemp = tmp$system.coefficients[8] %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    t2.setpoint = tmp$system.coefficients[9]  %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    ATP.read = tmp$system.coefficients[10]  %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    ATP.output = tmp$system.coefficients[11]  %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    ATP.time.shift = as.numeric(tmp$system.coefficients[12]),
                                    steps.per.inch = tmp$system.coefficients[13] %>% str_split_fixed(pattern = "[ ]", n = 2) %>% as.numeric,
                                    syringe.constant = as.numeric(tmp$system.coefficients[14]),
                                    RPM = tmp$system.coefficients[15]  %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    tmp$system.coefficients[16]  %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    software = tmp$system.coefficients[17]                                  
    )
  }
  if(grepl(x=tmp$system.coefficients[1], pattern = "(VPITC)")){
    tmp$system.coefficients <- list(system = tmp$system.coefficients[1],
                                    cell.volume = as.numeric(tmp$system.coefficients[2]),
                                    tmp$system.coefficients[3],
                                    jacket.t.read = tmp$system.coefficients[4] %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    shield.t.read = tmp$system.coefficients[5] %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    deltaT.read = as.numeric(tmp$system.coefficients[6]),
                                    Cal.Htr = tmp$system.coefficients[7]  %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    min.max.safetemp = tmp$system.coefficients[8] %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    t2.setpoint = tmp$system.coefficients[9]  %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    ATP.read = tmp$system.coefficients[10]  %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    ATP.output = tmp$system.coefficients[11]  %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    steps.per.inch = tmp$system.coefficients[12] %>% str_split_fixed(pattern = "[ ]", n = 2) %>% as.numeric,
                                    syringe.constant = as.numeric(tmp$system.coefficients[13]),
                                    RPM = tmp$system.coefficients[14]  %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    tmp$system.coefficients[15]  %>% str_split(pattern = "[,]") %>% unlist %>% as.numeric,
                                    software = tmp$system.coefficients[16]                                  
    )
  }
  
  return(tmp) 
}


#' Summary for class \code{itc} 
#' 
#' A generic summary function for objects of class \code{itc}.
#' 
#' @param object Object of class \code{itc}.
#' @return Invisible NULL.
#' @author Benjamin Weigel (bweigel@@ipb-halle.de)
#' @export
summary.itc <- function(object){
  
  
  cat("Object of class itc with", nrow(object$data), "rows of data.\n\n")
  cat("System Parameters: \n")
  cat("- Cell temperature:", object$inj.program$cell.temp.set, "C \n")
  cat("- Stirring speed:", object$inj.program$stirring.speed, "RPM \n")
  cat("- Reference power:", object$inj.program$reference.power, "ucal/s \n\n")
  cat("Concentrations: \n")
  cat("- in cell:", object$concentrations$cell,"mM \n")
  cat("- in syringe:", object$concentrations$syringe,"mM \n\n")
  cat("Injection Program: \n")
  cat("- Total Run Time:", max(object$X), "seconds\n")
  cat("- Total Injections:", object$inj.program$no.of.inj,"\n")
  cat("- Average Temperature:", mean(object$data$temp), "C \n\n")
  print(object$inj.program$program)
  
  invisible(NULL)
}


#' Convert class \code{itc} to class \code{hyperspec} 
#' 
#' A function to convert objects of class \code{itc} to \code{hyperspec} objects.
#' 
#' @param object Object of class \code{itc}.
#' @return an object of the class \code{hyperSpec}
#' @author Benjamin Weigel (bweigel@@ipb-halle.de)
#' @export
itc.concentrations <- function(object){
  CELL <- object$concentrations$cell
  SYRINGE <- object$concentrations$syringe
  VOL <- object$concentrations$cell.volume
  INJ.VOL <- object$inj.program$program$volume
  
  return(tmp)
}
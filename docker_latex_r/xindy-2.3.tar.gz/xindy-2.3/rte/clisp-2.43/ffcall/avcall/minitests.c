#define SKIP_EXTRA_STRUCTS
#include "tests.c"

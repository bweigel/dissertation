#' Calculate baseline for \code{itc} object
#' 
#' A function to find a baseline for objects of class \code{itc}
#' 
#' @param object Object of class \code{itc}.
#' @return \code{itc} object with baseline
#' @author Benjamin Weigel (bweigel@@ipb-halle.de)
#' @export
itc.baseline <- function(object, method="irls", external = F, use.bs = F, ...){
  
  if(all(exists("baseline", where = object$data), exists("corrected", where = object$data))){
    object$data <- subset(object$data, select=c(-baseline, -corrected))
    message("Overwriting previous baseline!")
  } 
  
  if(external){
    if (exists("baselineAlgorithms", envir = .GlobalEnv)) {
      bA <- get("baselineAlgorithms", envir = .GlobalEnv)
    }
    else {
      bA <- baselineAlgorithms
    }
    method <- match.arg(method, names(bA))
    baseFunc <- funcName(bA[[method]])
    
    spectra <- matrix(object$data$cp, nrow=1)
    res <- do.call(baseFunc, list(spectra, ...))
    object$data <- cbind(object$data, baseline = as.numeric(res$baseline), corrected = as.numeric(res$corrected))
  }
  
  if(!external){
    inj <- object$inj.program$injections.at
    bl <- splinefun(x = inj, y=object$data$cp[.vwhich(object$X, inj)], method = "natural")
    baseline <- bl(object$X)
    corrected <- object$data$cp - baseline
    object$data <- cbind(object$data, baseline = as.numeric(baseline), corrected = as.numeric(corrected))
    
  }
  
  class(object) <- "itc"
  return(object)
}


#' Integrate peaks for \code{itc} object
#' 
#' A function to integrate the peaks of objects of class \code{itc}
#' 
#' @param object Object of class \code{itc}.
#' @return \code{itc} object with baseline
#' @author Benjamin Weigel (bweigel@@ipb-halle.de)
#' @export
itc.integrate <- function(object, rule=5, method="integrate", ...){
  
  inj <- object$inj.program$injections.at
  lower <- inj
  upper <- inj + object$inj.program$program$spacing
  spl <- splinefun(object$X, object$data$corrected, method = "natural")
  
  iA <- c(chebyshev.u = "itc.int.cheb.u", 
          chebyshev.t = "itc.int.cheb.t",
          chebyshev.c = "itc.int.cheb.c",
          integrate = "itc.int.integrate")
  
  method <- match.arg(method, names(iA))
  iFunc <- iA[[method]]
  
  integrals <- do.call(iFunc, args = list(f = spl, lower = lower, upper = upper, rule = rule))
  
  object <- append(object, values = list(integrated = integrals))
  
  class(object) <- "itc"
  return(object)
}


#' @export
.vwhich <- function(obj, pts){
  tmp <- function(pts){
    which(obj == pts)
  }
  mywhich <- Vectorize(tmp)
  return(mywhich(pts)) 
}

#' Integrate with Cheb u
#' 
#' @param object Object of class \code{itc}.
#' @return \code{itc} object with baseline
#' @author Benjamin Weigel (bweigel@@ipb-halle.de)
#' @export
itc.int.cheb.u <- function(f, lower, upper, rule=5,...){
  
  rule <- chebyshev.u.quadrature.rules(n=20)[[rule]]
  
  integral <- function(lower, upper) {
    tmp <- chebyshev.u.quadrature(f, rule, lower = lower, upper = upper, ...)
    return(tmp)
  } 
  V_integrate <- Vectorize(integral)
  return(V_integrate(lower, upper))

}

#' Integrate with Cheb t
#' 
#' @param object Object of class \code{itc}.
#' @return \code{itc} object with baseline
#' @author Benjamin Weigel (bweigel@@ipb-halle.de)
#' @export
itc.int.cheb.t <- function(f, lower, upper, rule=5,...){
  
  rule <- chebyshev.t.quadrature.rules(n=20)[[rule]]
  
  integral <- function(lower, upper) {
    tmp <- chebyshev.t.quadrature(f, rule, lower = lower, upper = upper, ...)
    return(tmp)
  } 
  V_integrate <- Vectorize(integral)
  return(V_integrate(lower, upper))
  
}

#' Integrate with Cheb t
#' 
#' @param object Object of class \code{itc}.
#' @return \code{itc} object with baseline
#' @author Benjamin Weigel (bweigel@@ipb-halle.de)
#' @export
itc.int.cheb.c <- function(f, lower, upper, rule=5,...){
  
  rule <- chebyshev.c.quadrature.rules(n=20)[[rule]]
  
  integral <- function(lower, upper) {
    tmp <- chebyshev.c.quadrature(f, rule, lower = lower, upper = upper, ...)
    return(tmp)
  } 
  V_integrate <- Vectorize(integral)
  return(V_integrate(lower, upper))
  
}

#' Integrate with Cheb t
#' 
#' @param object Object of class \code{itc}.
#' @return \code{itc} object with baseline
#' @author Benjamin Weigel (bweigel@@ipb-halle.de)
#' @export
itc.int.integrate <- function(f, rule, lower, upper, ...){
  
  integral <- function(lower, upper) {
    tmp <- integrate(f, lower = lower, upper = upper, ...)$value
    return(tmp)
  } 
  V_integrate <- Vectorize(integral)
  return(V_integrate(lower, upper))
  
}

#' Integrate with Cheb t
#' 
#' @param object Object of class \code{itc}.
#' @return \code{itc} object with baseline
#' @author Benjamin Weigel (bweigel@@ipb-halle.de)
#' @export
itc.int.gegenbauer <- function(f, rule, lower, upper,  ...){
  
  rule <- gegenbauer.quadrature.rules(n=20)[[rule]]
  
  integral <- function(lower, upper) {
    tmp <- gegenbauer.quadrature(f, rule, lower = lower, upper = upper, ...)
    return(tmp)
  } 
  V_integrate <- Vectorize(integral)
  return(V_integrate(lower, upper))
  
}


#' PLot function for class \code{itc} 
#' 
#' A generic plot function for objects of class \code{itc}.
#' 
#' @param object Object of class \code{itc}.
#' @return Invisible NULL.
#' @author Benjamin Weigel (bweigel@@ipb-halle.de)
#' @export
plot.itc <- function(object, show.inject = T, show.temp = T){
  data <- object$data
  x <- object$X
  
  par(mar=c(5, 4, 4, 6) + 0.1)
  plot(x = x, y = data$cp, type="l", xlab = "time (s)", ylab = "power (ucal/s)", main="RAW ITC thermogram")
  
  if(exists("baseline", where = data)) {
    lines(x = x, y = data$baseline, col="red")
  }
  if(show.inject) {
    inj <- object$inj.program$injections.at
    abline(v = inj, lty=1, col="grey50")
    points(x = inj, y = data$cp[.vwhich(x, inj)], col="red")
  }
  if(show.temp){
    par(new=TRUE) 
    ## Plot the second plot and put axis scale on right
    plot(x = x, y = data$temp, pch=15,  xlab="", ylab="",  
         axes=FALSE, type="l", lty=1, col="lightsalmon1")
    mtext("temperature (C)",side=4,col="red",line=4) 
    axis(4, col="red",col.axis="red",las=1)
  }
  
  
  invisible(NULL)
}


/*
 * CLISP interface to PARI <http://pari.math.u-bordeaux.fr/>
 * Copyright (C) 2004 Sam Steingold
 * This is free software, distributed under the GNU GPL
 */

void init_for_clisp (long parisize, long maxprime);
void fini_for_clisp (int leaving);

